"""
Author: Mrinal Kanti Dhar
"""
