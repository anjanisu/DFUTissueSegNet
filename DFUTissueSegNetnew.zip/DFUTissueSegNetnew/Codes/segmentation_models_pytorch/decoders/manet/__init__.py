from .model import MAnet
