from .model import Linknet
